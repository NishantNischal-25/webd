import React from 'react';

const App = () => <div>Hello Divyansh </div>;

export default App;
